<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<%@ page import="java.sql.*" %> 
<%@ page import="javax.swing.*" %> 
<%
	String btnval=request.getParameter("b1");
	if(btnval.equalsIgnoreCase("login"))
	{ 
		String t1=request.getParameter("t1");
		String t2=request.getParameter("t2");
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student", "student");
			PreparedStatement psmt=conn.prepareStatement("insert into login values(?,?)");
			psmt.setString(1,t1);
			psmt.setString(2,t2);
			
			psmt.executeQuery();
			JOptionPane.showMessageDialog(null,"Record Saved.....");
		}
		catch(Exception e)
		{
			out.println(e.toString());
		}
	}//End of save
	
%>
</body>
</html>