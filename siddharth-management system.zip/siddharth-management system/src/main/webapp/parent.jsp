<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<%@ page import="java.sql.*" %> 
<%@ page import="javax.swing.*" %> 
<%
	String btnval=request.getParameter("b1");
	if(btnval.equalsIgnoreCase("save"))
	{ 
		String t1=request.getParameter("t1");
		String t2=request.getParameter("t2");
		String t3=request.getParameter("t3");
		String t4=request.getParameter("t4");
		String t5=request.getParameter("t5");
		String t6=request.getParameter("t6");
		String t7=request.getParameter("t7");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student", "student");
			PreparedStatement psmt=conn.prepareStatement("insert into parent values(?,?,?,?,?,?,?)");
			psmt.setString(1,t1);
			psmt.setString(2,t2);
			psmt.setString(3,t3);
			psmt.setString(4,t4);
			psmt.setString(5,t5);
			psmt.setString(6,t6);
			psmt.setString(7,t7);
			psmt.executeQuery();
			JOptionPane.showMessageDialog(null,"Record Saved.....");
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
		}
	}//End of save
	
	if(btnval.equalsIgnoreCase("delete"))
	{ 
		String t1=request.getParameter("t1");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student", "student");
			PreparedStatement psmt=conn.prepareStatement("delete from parent where parent_id=?");
			psmt.setString(1,t1);
			psmt.executeQuery();
			JOptionPane.showMessageDialog(null,"Record Deleted.....");
		}
		catch(Exception e)
		{
			out.println(e.toString());
		}
	}//End of delete
	
	if(btnval.equalsIgnoreCase("update"))
	{ 
		String t1=request.getParameter("t1");
		String t2=request.getParameter("t2");
		String t3=request.getParameter("t3");
		String t4=request.getParameter("t4");
		String t5=request.getParameter("t5");
		String t6=request.getParameter("t6");
		String t7=request.getParameter("t7");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student", "student");
			PreparedStatement psmt=conn.prepareStatement("update parent set fname=?,lname=?,dob=?,phone=?,mobile=?,status=? where parent_id=?");
			psmt.setString(7,t1);
			psmt.setString(1,t2);
			psmt.setString(2,t3);
			psmt.setString(3,t4);
			psmt.setString(4,t5);
			psmt.setString(5,t6);
			psmt.setString(6,t7);
			psmt.executeQuery();
			JOptionPane.showMessageDialog(null,"Record updated.....");
		}
		catch(Exception e)
		{
			out.println(e.toString());
		}
	}//End of update
	
	if(btnval.equalsIgnoreCase("allsearch"))
	{
	  try
	  {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student", "student");
			Statement smt=conn.createStatement();
			ResultSet rs=smt.executeQuery("select * from parent");
			%>
			<table border=2>
			<tr>
				<th>Parent Id</th>
				<th>Fname</th>
				<th>Lname</th>
				<th>Dob</th>
				<th>Phone</th>
				<th>Mobile</th>
				<th>Status</th>
			</tr>
			<%
			 while(rs.next())
			 {
			%>
				<tr>
					<th><%=rs.getString(1)%></th>
					<th><%=rs.getString(2)%></th>
					<th><%=rs.getString(3)%></th>
					<th><%=rs.getString(4)%></th>
					<th><%=rs.getString(5)%></th>
					<th><%=rs.getString(6)%></th>
					<th><%=rs.getString(7)%></th>
					
				</tr>
		    <%}%>
		         <input type=button value="Print" onclick="window.print()">
		        </table>
	    <%}
		catch(Exception e)
		{
			out.println(e.toString());
		}
	}//End of all search
	
	if(btnval.equalsIgnoreCase("psearch"))
	{
		String t1=request.getParameter("t1");
	  try
	  {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student", "student");
			Statement smt=conn.createStatement();
			ResultSet rs=smt.executeQuery("select * from parent where parent_id='"+t1+"'");
			%>
			<table border=2>
			<tr>
				<th>Parent Id</th>
				<th>Fname</th>
				<th>Lname</th>
				<th>Dob</th>
				<th>Phone</th>
				<th>Mobile</th>
				<th>Status</th>
			</tr>
			<%
			 while(rs.next())
			 {
			%>
				<tr>
					<th><%=rs.getString(1)%></th>
					<th><%=rs.getString(2)%></th>
					<th><%=rs.getString(3)%></th>
					<th><%=rs.getString(4)%></th>
					<th><%=rs.getString(5)%></th>
					<th><%=rs.getString(6)%></th>
					<th><%=rs.getString(7)%></th>
					
				</tr>
		    <%}%>
		         <input type=button value="Print" onclick="window.print()">
		        </table>
	    <%}
		catch(Exception e)
		{
			out.println(e.toString());
		}
	}//End of p search
	
	if(btnval.equalsIgnoreCase("find"))
	{
		String t1=request.getParameter("t1");
		String colnm=request.getParameter("s");
	  try
	  {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student", "student");
			Statement smt=conn.createStatement();
			ResultSet rs=smt.executeQuery("select * from parent where "+colnm+"="+"'"+t1+"'");
			%>
			<table border=2>
			<tr>
				<th>Parent Id</th>
				<th>Fname</th>
				<th>Lname</th>
				<th>Dob</th>
				<th>Phone</th>
				<th>Mobile</th>
				<th>Status</th>
			</tr>
			<%
			 while(rs.next())
			 {
			%>
				<tr>
					<th><%=rs.getString(1)%></th>
					<th><%=rs.getString(2)%></th>
					<th><%=rs.getString(3)%></th>
					<th><%=rs.getString(4)%></th>
					<th><%=rs.getString(5)%></th>
					<th><%=rs.getString(6)%></th>
					<th><%=rs.getString(7)%></th>
					
				</tr>
		    <%}%>
		         <input type=button value="Print" onclick="window.print()">
		        </table>
	    <%}
		catch(Exception e)
		{
			out.println(e.toString());
		}
	}//End of p search
%>
</body>
</html>