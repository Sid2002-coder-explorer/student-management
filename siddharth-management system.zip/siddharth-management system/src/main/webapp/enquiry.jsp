<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<%@ page import="java.sql.*" %> 
<%@ page import="javax.swing.*" %> 
<%
	String btnval=request.getParameter("b1");
	if(btnval.equalsIgnoreCase("save"))
	{ 
		String t1=request.getParameter("t1");
		String t2=request.getParameter("t2");
		String t3=request.getParameter("t3");
		String t4=request.getParameter("t4");
		String t5=request.getParameter("t5");
		String t6=request.getParameter("t6");
		String t7=request.getParameter("t7");
		String t8=request.getParameter("t8");
		String t9=request.getParameter("t9");
		String t10=request.getParameter("t10");
		String t11=request.getParameter("t11");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student", "student");
			PreparedStatement psmt=conn.prepareStatement("insert into enquiry values(?,?,?,?,?,?,?,?,?,?,?)");
			psmt.setString(1,t1);
			psmt.setString(2,t2);
			psmt.setString(3,t3);
			psmt.setString(4,t4);
			psmt.setString(5,t5);
			psmt.setString(6,t6);
			psmt.setString(7,t7);
			psmt.setString(8,t8);
			psmt.setString(9,t9);
			psmt.setString(10,t10);
			psmt.setString(11,t11);
			psmt.executeQuery();
			JOptionPane.showMessageDialog(null,"Record Saved.....");
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
		}
	}//End of save
	
	if(btnval.equalsIgnoreCase("allsearch"))
	{
	  try
	  {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "student", "student");
			Statement smt=conn.createStatement();
			ResultSet rs=smt.executeQuery("select * from enquiry");
			%>
			<table border=2>
			<tr>
				<th>Name</th>
				<th>Dob</th>
				<th>Gender</th>
				<th>Fname</th>
				<th>Address</th>
				<th>Contact</th>
				<th>Email</th>
				<th>Qualification</th>
				<th>College</th>
				<th>Course</th>
				<th>Date</th>
			</tr>
			<%
			 while(rs.next())
			 {
			%>
				<tr>
					<th><%=rs.getString(1)%></th>
					<th><%=rs.getString(2)%></th>
					<th><%=rs.getString(3)%></th>
					<th><%=rs.getString(4)%></th>
					<th><%=rs.getString(5)%></th>
					<th><%=rs.getString(6)%></th>
					<th><%=rs.getString(7)%></th>
					<th><%=rs.getString(8)%></th>
					<th><%=rs.getString(9)%></th>
					<th><%=rs.getString(10)%></th>
					<th><%=rs.getString(11)%></th>
				</tr>
		    <%}%>
		         <input type=button value="Print" onclick="window.print()">
		        </table>
	    <%}
		catch(Exception e)
		{
			out.println(e.toString());
		}
	}//End of all search
%>
</body>
</html>